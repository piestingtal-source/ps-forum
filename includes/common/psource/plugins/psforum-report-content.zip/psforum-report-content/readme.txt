=== PS Forum - Inhalt melden ===
Contributors: DerN3rd (WMS N@W)
Donate link: https://n3rds.work/spendenaktionen/unterstuetze-unsere-psource-free-werke/
Tags: forum, inhalte, moderation
Requires at least: 4.9
Tested up to: 5.6
Stable tag: 1.0.7
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Ermöglicht Benutzern, unangemessene Inhalte in Themen und Antworten zu melden.

== Description ==

Dieses kleine Plugin kommt gebündelt mit PS Forum zur alternativen aktivierung.
Es soll Dich dabei unterstützen dein Forum vor Unangemessenen Inhalten sauber zu halten, Dank Deiner Community.



[POWERED BY PSOURCE](https://n3rds.work/psource_kategorien/psource-plugins/)

= Hilfe und Support =

[Projektseite](https://n3rds.work/piestingtal_source/ps-forum-plugin/)
[Handbuch](https://n3rds.work/docs/ps-forum-plugin-handbuch/)
[Supportforum](https://n3rds.work/forums/forum/psource-support-foren/ps-forum-supportforum/)
[GitHub](https://github.com/piestingtal-source/ps-forum)

== Mehr PSOURCE ==

Erweitere die Möglichkeiten von Netzwerksuche mit kompatiblen PSOURCE Plugins und Themes


[POWERED BY PSOURCE](https://n3rds.work/psource_kategorien/psource-plugins/)

== Hilf uns ==

Viele, viele Kaffees konsumieren wir während wir an unseren Plugins und Themes arbeiten.
Wie wärs? Möchtest Du uns mit einer Kaffee-Spende bei der Arbeit an unseren Plugins unterstützen?

= Unterstütze uns =

Mach eine [Spende per Überweisung oder PayPal](https://n3rds.work/spendenaktionen/unterstuetze-unsere-psource-free-werke/) wir Danken Dir!

[POWERED BY PSOURCE](https://n3rds.work/psource_kategorien/psource-plugins/)

== ChangeLog ==

= 1.0.6 = DerN3rd =

* Release WMS N@W Netzwerksuche