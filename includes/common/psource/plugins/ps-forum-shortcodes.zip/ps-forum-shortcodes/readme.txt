=== PS Forum Shortcodes ===
Contributors: DerN3rd (WMS N@W)
Donate link: https://n3rds.work/spendenaktionen/unterstuetze-unsere-psource-free-werke/
Tags: multisite, suche, netzwerksuche
Requires at least: 4.9
Tested up to: 5.6
Stable tag: 2.2.3
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Das PS Forum Shortcodes-Plugin bietet eine TinyMCE-Dropdown-Schaltfläche im visuellen Editor, auf die Benutzer zugreifen können, um alle PSForum-Shortcodes zu verwenden.

== Description ==

Das PS Forum Shortcodes-Plugin bietet eine TinyMCE-Dropdown-Schaltfläche im visuellen Editor, auf die Benutzer zugreifen können, um alle PS Forum Shortcodes zu verwenden.

Es analysiert auch Shortcodes, die in Themen- und Antwortinhalten platziert sind.

Du kannst die Plugin-Einstellungen im Admin-Bereich verwenden, um die Funktionalität anzupassen.

== Screenshots ==



== ChangeLog ==

= 2.1.9 = DerN3rd =

* Overhauled von WPMUDEV
* Release WMS N@W Netzwerksuche