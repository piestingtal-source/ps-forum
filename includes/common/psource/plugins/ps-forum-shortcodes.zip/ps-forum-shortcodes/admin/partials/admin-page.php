<?php
/**
 * Represents the view for the administration dashboard.
 *
 * This includes the header, options, and other information that should provide
 * The User Interface to the end user.
 *
 * @package PSFS
 */
?>
<div class="wrap">
	<form id="psforum_shortcodes_options" action="options.php" method="post">
		<?php
			settings_fields( 'psforum_shortcodes' );
			do_settings_sections( 'psforum_shortcodes' );
			submit_button( 'Optionen speichern', 'primary', 'psforum_shortcodes_options_submit' );
		?>
		<div id="after-submit">
			<p>
				<?php esc_html_e( 'Brauchst Du Hilfe oder hast Du Vorschläge?', 'psforum-shortcodes' ); ?> <?php esc_html_e( 'kontaktiere uns im', 'psforum-shortcodes' ); ?> <a href="https://wordpress.org/support/plugin/psforum-shortcodes/" target="_blank"><?php esc_html_e( 'Plugin-Supportforum', 'psforum-shortcodes' ); ?></a>
			</p>
		</div>
	 </form>
</div>

