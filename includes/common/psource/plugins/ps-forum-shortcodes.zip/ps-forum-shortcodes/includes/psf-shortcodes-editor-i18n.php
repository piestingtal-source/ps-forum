<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$strings = 'tinyMCE.addI18n({' . _WP_Editors::$mce_locale . ': {
	psforum_shortcodes: {
		shortcode_title: "' . esc_js( __( 'PS Forum', 'psforum-shortcodes' ) ) . '",
		forums: "' . esc_js( __( 'Foren', 'psforum-shortcodes' ) ) . '",
		forum_index: "' . esc_js( __( 'Forum-Index', 'psforum-shortcodes' ) ) . '",
		forum_form: "' . esc_js( __( 'Neues Forum Formular', 'psforum-shortcodes' ) ) . '",
		single_forum: "' . esc_js( __( 'Einzelforum', 'psforum-shortcodes' ) ) . '",
		forum_id: "' . esc_js( __( 'Forum ID', 'psforum-shortcodes' ) ) . '",
		topic_id: "' . esc_js( __( 'Thema ID', 'psforum-shortcodes' ) ) . '",
		reply_id: "' . esc_js( __( 'Antwort ID', 'psforum-shortcodes' ) ) . '",
		tag_id: "' . esc_js( __( 'Schlagwort ID', 'psforum-shortcodes' ) ) . '",
		need_id: "' . esc_js( __( 'Du musst eine ID verwenden!', 'psforum-shortcodes' ) ) . '",
		topics: "' . esc_js( __( 'Themen', 'psforum-shortcodes' ) ) . '",
		topic_index: "' . esc_js( __( 'Themenindex', 'psforum-shortcodes' ) ) . '",
		topic_form: "' . esc_js( __( 'Neues Themenformular', 'psforum-shortcodes' ) ) . '",
		forum_topic_form: "' . esc_js( __( 'Spezifisches Forum Neues Themenformular', 'psforum-shortcodes' ) ) . '",
		single_topic: "' . esc_js( __( 'Einzelthema', 'psforum-shortcodes' ) ) . '",
		replies: "' . esc_js( __( 'Antworten', 'psforum-shortcodes' ) ) . '",
		reply_form: "' . esc_js( __( 'Neues Antwortformular', 'psforum-shortcodes' ) ) . '",
		single_reply: "' . esc_js( __( 'Einzelantwort', 'psforum-shortcodes' ) ) . '",
		topic_tags: "' . esc_js( __( 'Themen-Schlagworte', 'psforum-shortcodes' ) ) . '",
		display_topic_tags: "' . esc_js( __( 'Themen-Schlagwort anzeigen', 'psforum-shortcodes' ) ) . '",
		single_tag: "' . esc_js( __( 'Einzel-Schlagwort', 'psforum-shortcodes' ) ) . '",
		views: "' . esc_js( __( 'Ansichten', 'psforum-shortcodes' ) ) . '",
		popular: "' . esc_js( __( 'Beliebt', 'psforum-shortcodes' ) ) . '",
		no_replies: "' . esc_js( __( 'Keine Antworten', 'psforum-shortcodes' ) ) . '",
		search: "' . esc_js( __( 'Suche', 'psforum-shortcodes' ) ) . '",
		search_input: "' . esc_js( __( 'Eingabeformular für die Suche', 'psforum-shortcodes' ) ) . '",
		search_form: "' . esc_js( __( 'Suchformularvorlage', 'psforum-shortcodes' ) ) . '",
		account: "' . esc_js( __( 'Account', 'psforum-shortcodes' ) ) . '",
		login: "' . esc_js( __( 'Anmeldung', 'psforum-shortcodes' ) ) . '",
		register: "' . esc_js( __( 'Registrieren', 'psforum-shortcodes' ) ) . '",
		lost_pass: "' . esc_js( __( 'Passwort verloren', 'psforum-shortcodes' ) ) . '",
		statistics: "' . esc_js( __( 'Statistiken', 'psforum-shortcodes' ) ) . '"
	}
}});';
