;
(function($) {
    $(function() {
        var dates = $('.psf-datepicker').datepicker({
            dateFormat: 'yy-mm-dd',
            onSelect: function(selectedDate) {
                var option = $(this).is('#psf-report-start') ? 'minDate' : 'maxDate';
                var instance = $(this).data("datepicker");

                var date = $.datepicker.parseDate(
                    instance.settings.dateFormat ||
                    $.datepicker._defaults.dateFormat,
                    selectedDate, instance.settings);

                dates.not(this).datepicker("option", option, date);
            }
        });
    });
})(jQuery);