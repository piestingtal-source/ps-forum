<?php
/*
Plugin Name: PS Forum Statistiken
Plugin URI: https://n3rds.work/piestingtal_source/ps-forum-plugin/#ps-forum-statistiken
Description: Ein einfaches Reporting-Plugin für PS Forum
Version: 0.1.2
Author: DerN3rd
Author URI: https://n3rds.work/
License: GPL2
*/

/**
 * Copyright (c) 2021 WMS N@W. All rights reserved.
 *
 * Released under the GPL license
 * http://www.opensource.org/licenses/gpl-license.php
 *
 * This is an add-on for WordPress
 * http://wordpress.org/
 *
 * **********************************************************************
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * **********************************************************************
 */

// don't call the file directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * PSource_PSForum_Reports class
 *
 * @class PSource_PSForum_Reports The class that holds the entire PSource_PSForum_Reports plugin
 */
class PSource_PSForum_Reports {

    /**
     * Constructor for the PSource_PSForum_Reports class
     *
     * Sets up all the appropriate hooks and actions
     * within our plugin.
     *
     * @uses register_activation_hook()
     * @uses register_deactivation_hook()
     * @uses is_admin()
     * @uses add_action()
     */
    public function __construct() {
        $this->includes();
        $this->init_actions();
    }

    /**
     * Initializes the PSource_PSForum_Reports() class
     *
     * Checks for an existing PSource_PSForum_Reports() instance
     * and if it doesn't find one, creates it.
     */
    public static function init() {
        static $instance = false;

        if ( ! $instance ) {
            $instance = new PSource_PSForum_Reports();
        }

        return $instance;
    }

    /**
     * Include the required files
     *
     * @return void
     */
    public function includes() {
        require_once dirname( __FILE__ ) . '/includes/class-report.php';
    }

    /**
     * Initialize the action hooks
     *
     * @return void
     */
    public function init_actions() {
        // Localize our plugin
        add_action( 'init', array( $this, 'localization_setup' ) );

        add_action( 'admin_menu', array( $this, 'admin_menu' ) );

        // Loads frontend scripts and styles
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
    }

    /**
     * Initialize plugin for localization
     *
     * @uses load_plugin_textdomain()
     */
    public function localization_setup() {
        load_plugin_textdomain( 'psf-reports', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
    }

    /**
     * Register the admin menu
     *
     * @return void
     */
    public function admin_menu() {
        add_submenu_page( 'edit.php?post_type=forum', __( 'PS Forum Statistiken', 'psf-report' ), __( 'Statistiken', 'psf-reports' ), 'manage_options', 'psf-reports', array( $this, 'report_page' ) );
    }

    /**
     * Render the reports page
     *
     * @return void
     */
    public function report_page() {
        ?>
        <div class="wrap psf-reports">

            <?php
            $active_tab = isset( $_GET['tab'] ) ? $_GET['tab'] : 'conversation';
            $tabs = apply_filters( 'psf_reports_tabs', array(
                'conversation' => array(
                    'title'    => __( 'Gespräche', 'psf-reports' ),
                    'callback' => array( 'PSource_PSForum_Reporting', 'conversation' )
                ),
                // 'productivity' => array(
                //     'title'    => __( 'Productivity', 'psf-reports' ),
                //     'callback' => 'psf_report_productivity'
                // ),
                'team' => array(
                    'title'    => __( 'Team', 'psf-reports' ),
                    'callback' => array( 'PSource_PSForum_Reporting', 'report_team' )
                ),
            ) );
            ?>

            <h2 class="nav-tab-wrapper">
                <?php foreach ($tabs as $key => $tab) {
                    $active_class = ( $key == $active_tab ) ? ' nav-tab-active' : '';
                    ?>
                    <a href="<?php echo add_query_arg( array( 'tab' => $key ), admin_url( 'edit.php?post_type=forum&page=psf-reports' ) ); ?>" class="nav-tab<?php echo $active_class; ?>"><?php echo $tab['title'] ?></a>
                <?php } ?>
            </h2>

            <?php
            // call the tab callback function
            if ( array_key_exists( $active_tab, $tabs ) && is_callable( $tabs[$active_tab]['callback'] ) ) {
                call_user_func( $tabs[$active_tab]['callback'] );
            }
            ?>
        </div>
        <?php
    }

    /**
     * Enqueue admin scripts
     *
     * Allows plugin assets to be loaded.
     *
     * @uses wp_enqueue_script()
     * @uses wp_enqueue_style
     */
    public function enqueue_scripts() {
        global $wp_scripts;

        $suffix   = ( defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ) ? '' : '.min';

        wp_enqueue_style( 'psf-report-styles', plugins_url( 'assets/css/psf-reports.css', __FILE__ ) );
        wp_enqueue_style( 'jquery-ui', plugins_url( 'assets/css/jquery-ui.min.css', __FILE__ ) );

        /**
         * All scripts goes here
         */
        wp_enqueue_script( 'psf-report-scripts', plugins_url( "assets/js/script$suffix.js", __FILE__ ), array( 'jquery', 'jquery-ui-datepicker' ), false, true );
    }

} // PSource_PSForum_Reports

$reports = PSource_PSForum_Reports::init();
